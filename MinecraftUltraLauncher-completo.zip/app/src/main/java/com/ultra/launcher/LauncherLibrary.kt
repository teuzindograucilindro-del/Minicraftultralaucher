package com.ultra.launcher

/**
 * Ponto inicial para implementar futuramente a biblioteca e o gerenciamento
 * de versões do jogo. Nenhuma função de download ou inicialização está pronta.
 */
object LauncherLibrary {
    const val PROJECT_VERSION = "0.1.1"
}
