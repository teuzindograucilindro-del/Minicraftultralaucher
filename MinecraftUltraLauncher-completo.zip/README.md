# Minecraft Ultra Launcher

Projeto Android inicial, organizado para compilar um APK de depuração pelo GitHub Actions.

**Importante:** esta versão é apenas a base do aplicativo. Ela abre uma tela simples com o nome do projeto; ainda não autentica contas Microsoft, não baixa arquivos do Minecraft e não inicia o jogo.

## Compilar no GitHub
Envie o conteúdo deste ZIP para a raiz de um repositório GitHub, preservando as pastas. O workflow em `.github/workflows/gradle.yml` compila `app-debug.apk` e publica o APK em Artifacts.
